--[[
    GD50
    Super Mario Bros. Remake

    -- PlayState Class --
]]

PlayState = Class{__includes = BaseState}

function PlayState:init()
    self.camX = 0
    self.camY = 0
    self.level = LevelMaker.generate(100, 10)
    self.tileMap = self.level.tileMap
    self.background = math.random(3)
    self.backgroundX = 0
	-- creates an object for the level flag, used when the player reaches the end
	self.flag = self:levelFlag()
	-- creates an object for the level key
	self.key = nil

    self.gravityOn = true
    self.gravityAmount = 6

	local spawnPosition = 1

	while self.tileMap.tiles[10][spawnPosition].id ~= TILE_ID_GROUND do
		spawnPosition = spawnPosition + 1
	end

    self.player = Player({
        x = spawnPosition * 16 - 16, y = 0,
        width = 16, height = 20,
        texture = 'green-alien',
        stateMachine = StateMachine {
            ['idle'] = function() return PlayerIdleState(self.player) end,
            ['walking'] = function() return PlayerWalkingState(self.player) end,
            ['jump'] = function() return PlayerJumpState(self.player, self.gravityAmount) end,
            ['falling'] = function() return PlayerFallingState(self.player, self.gravityAmount) end
        },
        map = self.tileMap,
        level = self.level
    })

    self:spawnEnemies()

    self.player:changeState('falling')
	self.playerPos = {}
	--self.player.score = def.playerScore
end

function PlayState:update(dt)
    Timer.update(dt)

    -- remove any nils from pickups, etc.
    self.level:clear()

	-- create a key and a flag variable for later use
	if not self.key then
		self.key = self:levelKey()
	end
	if not self.flag then
		self.flag = self:levelFlag()
	end

	-- player position is saved to check if the player moved
	self.playerPos = {
		self.player.x,
		self.player.y
	}

    -- update player and level
    self.player:update(dt)
    self.level:update(dt)
    self:updateCamera()

	-- keys will follow the player if the are moving, and will fall to the ground if standing still
	if self.player.hasKey then
		if self.player.x ~= self.playerPos[1] or self.player.y ~= self.playerPos[2] then
			self:keyFollow()
		else
			self:keyFall()
		end
	end

	-- check to see if player reached the flag
	if self.player.reachedFlag then
		local distanceToRise = math.min(self.flag.y - self.player.y - 8, 40)

		if not self.flag.waving then

			-- freezes the player in place until the flag reaches them
			self.player.x = (self.levelSize - 1) * TILE_SIZE - 9
			self.player.y = math.max(self.player.y, self.flag.y - 48)

			-- changes the player to jumping state so that it keeps the jumping pose, but sets the vertical velocity to 0
			self.player:changeState('jump')
			self.player.dy = 0

			gSounds['flag']:play()

			-- tweens the flag up to the player position, always at the same speed
			Timer.tween(distanceToRise / 32, {
				[self.flag] = {y = self.flag.y - distanceToRise}
			})

			:finish(function()
				-- stops the flag rising sound when it reaches the player
				gSounds['flag']:stop()
				-- starts waving the flag
				self.flag.waving = true
				-- the player falls to the ground and will start walking right
				self.player:changeState('falling')
				Timer.tween(2, {
					[self.player] = {x - (self.levelSize + 1) * 16}
				})

				-- after reaching the right border, changes the level
				:finish(function()
					self.player.reachedFlag = false

					gStateMachine:change('play', {
						levelSize = self.levelSize + 10,
						playerScore = self.player.score
					})
				end)
			end)
		end
	end

    -- constrain player X no matter which state
    if self.player.x <= 0 then
        self.player.x = 0
    elseif self.player.x > TILE_SIZE * self.tileMap.width - self.player.width then
        self.player.x = TILE_SIZE * self.tileMap.width - self.player.width
    end
end

function PlayState:render()
    love.graphics.push()
    love.graphics.draw(gTextures['backgrounds'], gFrames['backgrounds'][self.background], math.floor(-self.backgroundX), 0)
    love.graphics.draw(gTextures['backgrounds'], gFrames['backgrounds'][self.background], math.floor(-self.backgroundX),
        gTextures['backgrounds']:getHeight() / 3 * 2, 0, 1, -1)
    love.graphics.draw(gTextures['backgrounds'], gFrames['backgrounds'][self.background], math.floor(-self.backgroundX + 256), 0)
    love.graphics.draw(gTextures['backgrounds'], gFrames['backgrounds'][self.background], math.floor(-self.backgroundX + 256),
        gTextures['backgrounds']:getHeight() / 3 * 2, 0, 1, -1)

    -- translate the entire view of the scene to emulate a camera
    love.graphics.translate(-math.floor(self.camX), -math.floor(self.camY))

    self.level:render()

    self.player:render()
    love.graphics.pop()

    -- render score
    love.graphics.setFont(gFonts['medium'])
    love.graphics.setColor(0, 0, 0, 1)
    love.graphics.print(tostring(self.player.score), 5, 5)
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.print(tostring(self.player.score), 4, 4)
end

function PlayState:updateCamera()
    -- clamp movement of the camera's X between 0 and the map bounds - virtual width,
    -- setting it half the screen to the left of the player so they are in the center
    self.camX = math.max(0,
        math.min(TILE_SIZE * self.tileMap.width - VIRTUAL_WIDTH,
        self.player.x - (VIRTUAL_WIDTH / 2 - 8)))

    -- adjust background X to move a third the rate of the camera for parallax
    self.backgroundX = (self.camX / 3) % 256
end

--[[
    Adds a series of enemies to the level randomly.
]]
function PlayState:spawnEnemies()
    -- spawn snails in the level
    for x = 1, self.tileMap.width do

        -- flag for whether there's ground on this column of the level
        local groundFound = false

        for y = 1, self.tileMap.height do
            if not groundFound then
                if self.tileMap.tiles[y][x].id == TILE_ID_GROUND then
                    groundFound = true

                    -- random chance, 1 in 20
                    if math.random(20) == 1 then

                        -- instantiate snail, declaring in advance so we can pass it into state machine
                        local snail
                        snail = Snail {
                            texture = 'creatures',
                            x = (x - 1) * TILE_SIZE,
                            y = (y - 2) * TILE_SIZE + 2,
                            width = 16,
                            height = 16,
                            stateMachine = StateMachine {
                                ['idle'] = function() return SnailIdleState(self.tileMap, self.player, snail) end,
                                ['moving'] = function() return SnailMovingState(self.tileMap, self.player, snail) end,
                                ['chasing'] = function() return SnailChasingState(self.tileMap, self.player, snail) end
                            }
                        }
                        snail:changeState('idle', {
                            wait = math.random(5)
                        })

                        table.insert(self.level.entities, snail)
                    end
                end
            end
        end
    end
end

function PlayState:keyFollow()
	local posX
	local posY
	if self.player.direction == 'right' then
		-- set the target position of the key behind the player
		posX = self.player.x - 16
		posY = self.player.y + 8

		-- moves the key toward its target position
		self.key.dx = (posX - self.key.x) * 8
		self.key.dy = (posY - self.key.y) * 8
	else
		posX = self.player.x + 16
		posY = self.player.y + 8

		self.key.dx = (posX - self.key.x) * 8
		self.key.dy = (posY - self.key.y) * 8
	end
end

function PlayState:keyFall()
	local leftHeight
	local rightHeight
	local y = 10

	while y > 1 do
		if math.ceil(self.key.x / TILE_SIZE) > 0 and self.tileMap.tiles[y][math.ceil(self.key.x / TILE_SIZE)].topper then
			leftHeight = (y - 2) * TILE_SIZE
		end
		y = y - 1
	end
	y = 10
	while y > 1 do
		if math.ceil((self.key.x + 16) / TILE_SIZE) > 0 and self.tileMap.tiles[y][math.ceil((self.key.x + 16) / TILE_SIZE)].topper then
			rightHeight = (y - 2) * TILE_SIZE
		end
		y = y - 1
	end

	if not leftHeight then
	leftHeight = 8.5 * TILE_SIZE
	end
	if not rightHeight then
	rightHeight = 8.5 * TILE_SIZE
	end

	local keyHeight = math.min(leftHeight, rightHeight)

	self.key.dx = 0
	self.key.dy = (keyHeight - self.key.y) * 5
end

function PlayState:levelFlag()
	for k = 1, #self.level.objects do
		if self.level.objects[k].texture == 'flags-and-poles' and self:contains(FLAGS, self.level.objects[k].frame) then
			return self.level.objects[k]
		end
	end

	return nil
end

function PlayState:levelKey()
	for k = 1, #self.level.objects do
		if self.level.objects[k].texture == 'keys-and-locks' and self:contains(KEYS, self.level.objects[k].frame) then
			return self.level.objects[k]
		end
	end

	return nil
end

function PlayState:contains(list, value)
	for k = 1, #list do
		if list[k] == value then
			return true
		end
	end

	return false
end


