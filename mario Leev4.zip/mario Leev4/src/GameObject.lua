--[[
    GD50
    -- Super Mario Bros. Remake --

    Author: Colton Ogden
    cogden@cs50.harvard.edu
]]

GameObject = Class{}

function GameObject:init(def)
    self.x = def.x
    self.y = def.y
	self.dx = def.dx or 0
	self.dy = def.dy or 0
    self.texture = def.texture
    self.width = def.width
    self.height = def.height
    self.frame = def.frame
	self.initialFrame = self.frame
	self.flipped = def.flipped or false
    self.solid = def.solid
    self.collidable = def.collidable
    self.consumable = def.consumable
    self.onCollide = def.onCollide
    self.onConsume = def.onConsume
    self.hit = def.hit
	self.onTouch = def.onTouch
	self.waving = def.waving or false
	self.timer = 0
	self.currentFrame = 0
	self.isVisible = def.visible
end

function GameObject:collides(target)
    return not (target.x > self.x + self.width or self.x > target.x + target.width or
            target.y > self.y + self.height or self.y > target.y + target.height)
end

function GameObject:update(dt)
	self.x = math.floor(self.x + self.dx * dt + 0.5)
	self.y = math.floor(self.y + self.dy * dt + 0.5)

	if self.waving then
		self.timer = self.timer + dt

		if self.timer >= 0.2 then
			self.currentFrame = (self.currentFrame + 1) % 2
			self.frame = self.initialFrame - self.currentFrame - 1
			self.timer = 0
		end
	end
end


function GameObject:render()
	if self.isVisible then
		love.graphics.draw(gTextures[self.texture], gFrames[self.texture][self.frame], self.x, self.y, 0, self.flipped and -1 or 1, 1)
	end
end
