--[[

	GD50
	Pokemon

	Author: Lee Johnson
	ljohnso2@alumni.drew.edu

	code for the levelUpState that is implemented in the "victory" function of the
	TakeTurnState class
]]



levelUpStatsState = Class{__includes = BaseState}

function LevelUpStatsState:init(def)
	self.statesMenu = Menu{
		x = VIRTUAL_WIDTH - 170,
		y  VIRTUAL_HEIGHT - 158,
		width = 170,
		height = 150,
		items = def.levelUpStats,
		cursorOn = false
	}

	self.onClose = def.onClose
end

function LevelUpStatsState:update(dt)
	self.statsMenu:update(dt)

	if love.keyboard.wasPressed('enter') or love.keyboard.wasPressed('return') then
		gStateStack:pop()
		self:onClose()
	end
end

function LevelUpStatsState:render()
	self.statsMenu:render()
end
