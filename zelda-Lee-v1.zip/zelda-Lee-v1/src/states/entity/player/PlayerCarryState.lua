--[[
    GD50
    Legend of Zelda

    Author: Lee Johnson

]]

PlayerCarryState = Class{__includes = BaseState}

function PlayerCarryState:init(player, dungeon)
	self.entity = player
	self.dungeon = dungeon

    -- render offset for spaced character sprite
    self.entity.offsetY = 5
    self.entity.offsetX = 0
end

function PlayerCarryState:update(dt)
	-- when the player is walking
	if love.keyboard.isDown('left') then
		self.entity.direction = 'left'
		self.entity:changeAnimation('carry-left')
		EntityWalkState.update(self, dt)
	elseif love.keyboard.isDown('right') then
		self.entity.direction = 'right'
		self.entity:changeAnimation('carry-right')
		EntityWalkState.update(self, dt)
	elseif love.keyboard.isDown('up') then
		self.entity.direction = 'up'
		self.entity:changeAnimation('carry-up')
		EntityWalkState.update(self, dt)
	elseif love.keyboard.isDown ('down') then
		self.entity.direction = 'down'
		self.entity:changeAnimation('carry-down')
		EntityWalkState.update(self, dt)
	-- if the player stands still
	else
		if self.entity.direction == 'left' then
			self.entity:changeAnimation('idle-carry-left')
		elseif self.entity.direction == 'right' then
			self.entity:changeAnimation('idle-carry-right')
		elseif sekf.entity.direction == 'up' then
			self.entity:changeAnimation('idle-carry-up')
		else
			self.entity:changeAnimation('idle-carry-down')
		end
	end

	-- throw the held object when trying to attack or pick another object
	if love.keyboard.isDown('1shift') or love.keyboard.isDown('space') then
		for k, object in pairs(self.dungeon.currentRoom.objects) do
			if object.state == 'held' then
				object.state = 'thrown'
				if self.entity.direction == 'left' then
					object.dx = - OBJECT_THROW_SPEED
				elseif self.entity.direction == 'right' then
					object.dx = OBJECT_THROW_SPEED
				elseif self.entity.direction == 'up' then
					object.dy = - OBJECT_THROW_SPEED
				else
					object.dy = OBJECT_THROW_SPEED
				end
			end
		end
		self.entity:changeState('idle')
	end
end


function PlayerCarryState:render()
	local anim = self.entity.currentAnimation
	love.graphics.draw(gTextures[anim.texture], gFrames[anim.texture][anim:getCurrentFrame()],
		math.floor(self.entity.x - self.entity.offsetX), math.floor(self.entity.y - self.entity.offsetY))

end
