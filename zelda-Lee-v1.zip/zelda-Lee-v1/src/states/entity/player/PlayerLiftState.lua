--[[
    GD50
    Legend of Zelda

    Author: Lee Johnson

]]

PlayerLiftState = Class{__includes = BaseState}

function PlayerLiftState:init(player, dungeon)
	self.player = player
	self.dungeon = dungeon

    -- render offset for spaced character sprite
    self.entity.offsetY = 5
    self.entity.offsetX = 0

	local direction = self.player.direction

	local liftAreaX, liftAreaY, liftAreaWidth, liftAreaHeight

	-- creates the lifting area like a hitbox
	if direction == 'left' then
		liftAreaWidth = 4
		liftAreaHeight = 4
		liftAreaX = self.player.x - liftAreaWidth
		liftAreaY = self.player.y + 2 * self.player.height / 3
	elseif direction == 'right' then
		liftAreaWidth = 4
		liftAreaHeight = 4
		liftAreaX = self.player.x + self.player.width
		liftAreaY = self.player.y + 2 * self.player.height / 3
	elseif direction == 'up' then
		liftAreaWidth = 4
		liftAreaHeight = 4
		liftAreaX = self.player.x + self.player.width / 2 - liftAreaWidth / 2
		liftAreaY = self.player.y - liftAreaHeight
	else
		liftAreaWidth = 4
		liftAreaHeight = 4
		liftAreaX = self.player.x + self.player.width / 2 - liftAreaWidth / 2
		liftAreaY = self.player.y + liftAreaHeight + self.player.height - 3
	end

	self.liftArea = Hitbox(liftAreaX, liftAreaY, liftAreaWidth, liftAreaHeight)
	self.player:changeAnimation('lift-' ..self.player.direction)
end

function PlayerLiftState:update(dt)
	local objectFound = false

	-- check if there's any object in front of the player
    for k, object in pairs(self.dungeon.currentRoom.objects) do
		-- if the player is in front of a movable object
		if object:collides(self.liftArea) and object.movable then
			objectFound = true
			object.solid = false
			if self.player.direction == 'left' then
				object.x = self.player.x - object.width / 2
				object.y = self.player.y + self.player.height / 2
				object.inFront = true
			elseif self.player.direction == 'right' then
				object.x = self.player.x + self.player.width / 2
				object.y = self.player.y + self.player.height / 2
				object.inFront = true
			elseif self.player.direction == 'up' then
				object.x = self.player.x
				object.y = self.player.y - 2
				object.inFront = false
			elseif self.player.direction == 'down' then
				object.x = self.player.x
				object.y = self.player.y + self.player.height / 2
				object.inFront = true
			end

			-- sets the object position to the position of the player hand for wach frame of animation
			if self.player.currentAnimation.currentFrame == 1 then
				object.z = 0
			elseif self.player.currentAnimation.currentFrame == 2 then
				object.z = -8
			-- sets the object position above the player head
			else
				self.player.currentAnimation.currentFrame = 1
				object.z = -16
				object.state = 'held'
				self.player:changeState('carry')
			end
		end
	end

	-- if it's not in front of any object, don't play the animation
	if not objectFound then
		self.player:changeState('idle')
	end
end

function PlayerLiftState:render()
	local anim = self.player.currentAnimation
	love.graphics.draw(gTextures[anim.texture], gFrames[anim.texture][anim:getCurrentFrame()],
		math.floor(self.player.x - self.player.offsetX), math.floor(self.player.y - self.player.offsetY))

		--
    -- debug for player and pick area

    -- [[love.graphics.setColor(255, 0, 255, 255)
    -- love.graphics.rectangle('line', self.player.x, self.player.y, self.player.width, self.player.height)
    -- love.graphics.rectangle('line', self.liftArea.x, self.liftArea.y,
    --     self.liftArea.width, self.liftArea.height)
    -- love.graphics.setColor(255, 255, 255, 255)]]
end
