--[[
    GD50
    Legend of Zelda

    Author: Colton Ogden
    cogden@cs50.harvard.edu
]]

GAME_OBJECT_DEFS = {
    ['switch'] = {
        type = 'switch',
        texture = 'switches',
        frame = 2,
        width = 16,
        height = 16,
        solid = false,
        defaultState = 'unpressed',
        states = {
            ['unpressed'] = {
                frame = 2
            },
            ['pressed'] = {
                frame = 1
            }
        }
    },
    ['pot'] = {
        type = 'pot',
		texture = 'pots',
		frame = 1,
		width = 16,
		height = 16,
		solid = true,
		movable = true,
		defaultState = 'intact',
		states = {
			['intact'] = {
				frame = 1
			},
			['held'] = {
				frame = 1,
				solid = false,
				inFront = true
			},
			['thrown'] = {
				frame = 1
			},
			['cracked'] = {
				frame = 4
			},
			['broken'] = {
				frame = 7
			},
			['shattered'] = {
				frame = 12,
				solid = false
			}
		}
    },
	['extra-life'] = {
		type = 'extra-life',
		texture = 'extra-life',
		frame = 1,
		width = 16,
		height = 16,
		defaultState = 'normalState',
		states = {
			['normalState'] = {
				frame = 1
			}
		}
	}
}

