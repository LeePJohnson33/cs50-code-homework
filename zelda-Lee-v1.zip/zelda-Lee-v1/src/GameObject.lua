--[[
    GD50
    Legend of Zelda

    Author: Colton Ogden
    cogden@cs50.harvard.edu
]]

GameObject = Class{}

function GameObject:init(def, x, y)

    -- string identifying this object type
    self.type = def.type

    self.texture = def.texture
	self.variety = variety or 0
    self.frame = def.frame or 1

    -- whether it acts as an obstacle or not
    self.solid = def.solid

	-- whether the object can be picked up or not
	self.movable = def.movable or false

	-- whether we habe to draw the object shadow or not
	self.hasShadow = def.shadow or false

	--object animation
	--self.animation = self:createAnimations(def.animations)

	self.inFront = false

    self.defaultState = def.defaultState
    self.state = self.defaultState
    self.states = def.states

    -- dimensions
    self.x = x
    self.y = y
	self.z = 0
    self.width = def.width
    self.height = def.height

	-- speed
	self.dx = 0
	self.dy = 0
	self.dz = 0

	-- gravity
	self.gravity = def.gravity or 0

	-- timer used for animations
	self.timer = 0


    -- default empty collision callback
    self.onCollide = function() end
end

function GameObject:update(dt)
	-- update the position and velocity
	self.x = math.floor(self.x + self.dx * dt)
	self.y = math.floor(self.y + self.dy * dt)
	self.z = math.floor(self.z + self.dz * dt)

	self.dz = self.dz + self.gravity * dt
end

function GameObject:collides(target)
	return not (self.x + self.width < target.x + 1 or self.x >= target.x + target.width - 1 or
				self.y + self.height < target.y + 1 or self.y >= target.y + target.height - 1)
end

function GameObject:render(adjacentOffsetX, adjacentOffsetY)
    love.graphics.draw(gTextures[self.texture], gFrames[self.texture][self.states[self.state].frame + self.variety or self.frame + self.variety],
        self.x + adjacentOffsetX, self.y + adjacentOffsetY + self.z)
end
