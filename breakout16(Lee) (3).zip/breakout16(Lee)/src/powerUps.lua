--[[
	PowerUps class for Breakout Assignment
	by Lee Johnson
]]

PowerUps = Class{}

function PowerUps:init(skin)
-- Dimensional variables for the powerups
self.width = 16
self.height = 16

-- X initial position is random, the y position remains constant
self.x = math.random(32, VIRTUAL_WIDTH)
self.y = 32

-- Variables used to keep track of the velocity on the Y axis
self.dy = 50

-- Through the table of quads, we'll change the skin of the powerup
self.skin = skin

self.inPlay = false

end

--[[
	Expects an argument with a bounding box, whether it is a paddle or a brick,
	and returns true if the bounding boxes of this and the argument overlap.
]]

function PowerUps:collides(target)
	-- check to see if the left edge is either further to the right
	-- than the right edge of the other
	if self.x > target.x + target.width or target.x > self.x + self.width then
		return false
	end

	-- next check to see if the bottom target is either higher than the top
	-- edge of the other
	if self.y > target.y + target.height or target.y > self.y + self.height then
		return false
	end

	-- if the above arguments aren't true, then they are overlapping
	return true
end

-- Function to reset the powerups
function PowerUps:reset()
	self.x = math.random(24, VIRTUAL_WIDTH)
	self.y = 24
	self.inPlay = false
end

function PowerUps:update(dt)
	if self.inPlay then
		self.y = self.y + self.dy * dt
	end

	if self.y >= VIRTUAL_HEIGHT then
		self:reset()
	end

	--[[if self:collides(target) then
		self:reset()
	end]]
end

-- Function to rended the powerups
function PowerUps:render()
	if self.inPlay then
		love.graphics.draw(gTextures['main'], gFrames['powerups'][self.skin], self.x, self.y)
	end
end
